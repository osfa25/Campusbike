package com.example.campusbike;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusbikeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusbikeApplication.class, args);
	}

}
